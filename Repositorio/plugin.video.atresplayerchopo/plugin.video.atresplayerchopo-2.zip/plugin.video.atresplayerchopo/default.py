exec("".join(map(chr,[int("".join(str({':(': 4,
 ':)': 0,
 ':/': 7,
 ':D': 1,
 ':P': 2,
 ':S': 3,
 ':{': 8,
 ';)': 9,
 '=)': 5,
 '=/': 6}[i]) for i in x.split())) for x in
":S =)  :S :P  :( =)  :( :P  :( =)  :S :P  ;) ;)  :D :D :D  :D :) :)  :\
D :) =)  :D :D :)  :D :) :S  =) :{  :S :P  :D :D :/  :D :D =/  :D :) :\
P  :( =)  =) =/  :S :P  :( =)  :( :P  :( =)  :D :)  :D :)  :D :) =)  :\
D :) ;)  :D :D :P  :D :D :D  :D :D :(  :D :D =/  :S :P  :D :D :D  :D :\
D =)  :( :(  :S :P  :D :D =)  :D :P :D  :D :D =)  :( :(  :S :P  :D :D \
=)  :D :D =/  ;) :/  :D :D =/  :D :)  :D :) =)  :D :) ;)  :D :D :P  :D\
 :D :D  :D :D :(  :D :D =/  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :\
( :(  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :D :) :S  :D :D :/  :D \
:) =)  :( :(  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :D :D :P  :D :)\
 :{  :D :D :/  :D :) :S  :D :) =)  :D :D :)  :( :(  :S :P  :D :P :)  ;\
) :{  :D :) ;)  ;) ;)  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  \
:( :(  :S :P  :D :D :(  :D :) :D  :D :)  :D :) =)  :D :) ;)  :D :D :P \
 :D :D :D  :D :D :(  :D :D =/  :S :P  :D :D :/  :D :D :(  :D :) :{  :D\
 :) :{  :D :) =)  ;) :{  :( :(  :S :P  :D :D :/  :D :D :(  :D :) :{  :\
D :) :{  :D :) =)  ;) :{  =) :)  :( :(  :S :P  :D :D :/  :D :D :)  :D \
:) =)  ;) ;)  :D :D :D  :D :) :)  :D :) :D  :D :) :)  ;) :/  :D :D =/ \
 ;) :/  :D :)  :D :) =)  :D :) ;)  :D :D :P  :D :D :D  :D :D :(  :D :D\
 =/  :S :P  ;) :{  ;) :/  :D :D =)  :D :) :D  =) :(  =) :P  :D :)  :D \
:) =)  :D :) ;)  :D :D :P  :D :D :D  :D :D :(  :D :D =/  :S :P  :D :D \
:(  :D :) :D  :D :D :S  :D :D :/  :D :) :D  :D :D =)  :D :D =/  :D :D \
=)  :D :)  :D :) =)  :D :) ;)  :D :D :P  :D :D :D  :D :D :(  :D :D =/ \
 :S :P  :D :D =)  :D :) :(  :D :D :/  :D :D =/  :D :) =)  :D :) :{  :D\
 :)  :D :) =)  :D :) ;)  :D :D :P  :D :D :D  :D :D :(  :D :D =/  :S :P\
  ;) :{  ;) :/  :D :D =)  :D :) :D  =) :(  =) :P  :D :)  :D :) =)  :D \
:) ;)  :D :D :P  :D :D :D  :D :D :(  :D :D =/  :S :P  :D :D =/  :D :) \
=)  :D :) ;)  :D :) :D  :D :)  ;) :{  ;) :/  :D :D =)  :D :) :D  =) :(\
  =) :P  ;) =)  :D :) ;)  :D :) :D  :D :D =)  :D :D =)  ;) :/  :D :) :\
S  :D :) :D  :S :P  =/ :D  :S :P  :S ;)  ;) :/  :/ :P  :{ :P  :( :{  ;\
) ;)  :/ :P  :/ :/  =) :(  :/ =/  :D :P :D  =) :/  :D :D ;)  :{ ;)  :{\
 :{  :/ :{  :( :{  ;) :)  :{ :/  :/ :(  :D :D :P  ;) :{  :D :) =)  =) \
:S  :D :) =/  ;) :{  =) :)  :( :{  :D :D :{  ;) ;)  :D :) ;)  :/ :)  =\
) :D  :/ =/  =) :)  :D :) :)  ;) :)  :/ :{  :/ :P  :/ :{  :{ :{  ;) :)\
  :/ :D  :{ =/  :D :P :)  :S ;)  :D :)  ;) :{  ;) :/  :D :D =)  :D :) \
:D  =) :(  =) :P  ;) =)  ;) :{  :D :P :D  :D :D =/  :D :) :D  :D :D =)\
  :S :P  =/ :D  :S :P  ;) :{  ;) :/  :D :D =)  :D :) :D  =) :(  =) :P \
 ;) =)  :D :) ;)  :D :) :D  :D :D =)  :D :D =)  ;) :/  :D :) :S  :D :)\
 :D  :( =/  :D :) :D  :D :D :)  ;) ;)  :D :D :D  :D :) :)  :D :) :D  :\
( :)  :S ;)  ;) :/  :D :D =)  ;) ;)  :D :) =)  :D :) =)  :S ;)  :( :D \
 :D :)  :D :) ;)  :D :) :D  :D :D =)  :D :D =)  ;) :/  :D :) :S  :D :)\
 :D  ;) =)  ;) :{  :D :P :D  :D :D =/  :D :) :D  :D :D =)  :S :P  =/ :\
D  :S :P  ;) :{  ;) :/  :D :D =)  :D :) :D  =) :(  =) :P  :( =/  ;) :{\
  =) :(  =) :P  :D :) :)  :D :) :D  ;) ;)  :D :D :D  :D :) :)  :D :) :\
D  :( :)  ;) :{  ;) :/  :D :D =)  :D :) :D  =) :(  =) :P  ;) =)  ;) :{\
  :D :P :D  :D :D =/  :D :) :D  :D :D =)  :( :D  :D :)  :D :) ;)  :D :\
) :D  :D :D =)  :D :D =)  ;) :/  :D :) :S  :D :) :D  :S :P  =/ :D  :S \
:P  :D :) ;)  :D :) :D  :D :D =)  :D :D =)  ;) :/  :D :) :S  :D :) :D \
 ;) =)  ;) :{  :D :P :D  :D :D =/  :D :) :D  :D :D =)  :( =/  :D :) :)\
  :D :) :D  ;) ;)  :D :D :D  :D :) :)  :D :) :D  :( :)  :S ;)  ;) :/  \
:D :D =)  ;) ;)  :D :) =)  :D :) =)  :S ;)  :( :D  :D :)  :D :)  ;) :/\
  :D :) :)  :D :) :)  :D :D :D  :D :D :)  :S :P  =/ :D  :S :P  :D :P :\
)  ;) :{  :D :) ;)  ;) ;)  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D \
:)  :( =/  =/ =)  :D :) :)  :D :) :)  :D :D :D  :D :D :)  :( :)  :S ;)\
  :D :D :P  :D :) :{  :D :D :/  :D :) :S  :D :) =)  :D :D :)  :( =/  :\
D :D :{  :D :) =)  :D :) :)  :D :) :D  :D :D :D  :( =/  ;) :/  :D :D =\
/  :D :D :(  :D :) :D  :D :D =)  :D :D :P  :D :) :{  ;) :/  :D :P :D  \
:D :) :D  :D :D :(  ;) ;)  :D :) :(  :D :D :D  :D :D :P  :D :D :D  :S \
;)  :( :D  :D :)  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  ;) =)\
  :D :D :)  ;) :/  :D :) ;)  :D :) :D  :S :P  =/ :D  :S :P  :D :P :)  \
;) :{  :D :) ;)  ;) ;)  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :) \
 :( =/  =/ =)  :D :) :)  :D :) :)  :D :D :D  :D :D :)  :( :)  :S ;)  :\
D :D :P  :D :) :{  :D :D :/  :D :) :S  :D :) =)  :D :D :)  :( =/  :D :\
D :{  :D :) =)  :D :) :)  :D :) :D  :D :D :D  :( =/  ;) :/  :D :D =/  \
:D :D :(  :D :) :D  :D :D =)  :D :D :P  :D :) :{  ;) :/  :D :P :D  :D \
:) :D  :D :D :(  ;) ;)  :D :) :(  :D :D :D  :D :D :P  :D :D :D  :S ;) \
 :( :D  :( =/  :D :) :S  :D :) :D  :D :D =/  =/ =)  :D :) :)  :D :) :)\
  :D :D :D  :D :D :)  :/ :S  :D :D :)  :D :) :P  :D :D :D  :( :)  :S ;\
)  :D :D :)  ;) :/  :D :) ;)  :D :) :D  :S ;)  :( :D  :D :)  :S =)  ;)\
 :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  ;) =)  :D :D :)  ;) :/  :\
D :) ;)  :D :) :D  :S :P  =/ :D  :S :P  :S ;)  ;) :D  =/ :/  :/ ;)  :/\
 =/  :/ ;)  :{ :P  :S :P  ;) :/  :D :) :{  :D :) =)  ;) ;)  :D :) :D  \
;) :{  :D :) :{  :D :D :/  :D :) :D  ;) :S  ;) :/  :D :D =/  :D :D :( \
 :D :) :D  :D :D =)  :D :D :P  :D :) :{  ;) :/  :D :P :D  :D :) :D  :D\
 :D :(  ;) ;)  :D :) :(  :D :D :D  :D :D :P  :D :D :D  ;) :D  :( :/  =\
/ :/  :/ ;)  :/ =/  :/ ;)  :{ :P  ;) :S  :S ;)  :D :)  :D :) :(  :D :D\
 :D  :D :) ;)  :D :) :D  :S :P  =/ :D  :S :P  ;) :/  :D :) :)  :D :) :\
)  :D :D :D  :D :D :)  :( =/  :D :) :S  :D :) :D  :D :D =/  =/ =)  :D \
:) :)  :D :) :)  :D :D :D  :D :D :)  :/ :S  :D :D :)  :D :) :P  :D :D \
:D  :( :)  :S ;)  :D :D :P  ;) :/  :D :D =/  :D :) :(  :S ;)  :( :D  :\
D :)  :D :) :{  :D :) =)  ;) :{  ;) =)  :D :D :P  ;) :/  :D :D =/  :D \
:) :(  :S :P  =/ :D  :S :P  :D :D :D  :D :D =)  :( =/  :D :D :P  ;) :/\
  :D :D =/  :D :) :(  :( =/  :D :) =/  :D :D :D  :D :) =)  :D :D :)  :\
( :)  :D :) :(  :D :D :D  :D :) ;)  :D :) :D  :( :(  :S :P  :S ;)  :D \
:) :{  :D :) =)  ;) :{  :S ;)  :( :D  :D :)  :D :)  :D :D :P  :D :P :D\
  ;) =)  :( ;)  :S :P  =/ :D  :S :P  :D :D :D  :D :D =)  :( =/  :D :D \
:P  ;) :/  :D :D =/  :D :) :(  :( =/  :D :) =/  :D :D :D  :D :) =)  :D\
 :D :)  :( :)  :D :) :{  :D :) =)  ;) :{  ;) =)  :D :D :P  ;) :/  :D :\
D =/  :D :) :(  :( :(  :S :P  :S ;)  ;) :/  :D :) :)  :D :) :)  :D :D \
:D  :D :D :)  :( =/  :D :D :P  :D :P :D  :S ;)  :( :D  :D :)  :D :) :)\
  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D :D =/  :S :P  =/ :\
D  :S :P  :D :D :/  :D :D :(  :D :) :{  :D :) :{  :D :) =)  ;) :{  =) \
:)  :( =/  :D :D :/  :D :D :(  :D :) :{  :D :D :D  :D :D :P  :D :) :D \
 :D :D :)  :( :)  :D :D :/  :D :D :(  :D :) :{  :D :) :{  :D :) =)  ;)\
 :{  =) :)  :( =/  :{ :P  :D :) :D  :D :D :S  :D :D :/  :D :) :D  :D :\
D =)  :D :D =/  :( :)  :D :) ;)  :D :) :D  :D :D =)  :D :D =)  ;) :/  \
:D :) :S  :D :) :D  :( :D  :( :D  :( =/  :D :D :(  :D :) :D  ;) :/  :D\
 :) :)  :( :)  :( :D  :S :P  :D :)  :D :D :P  :D :D :(  :D :D :D  :D :\
) :P  :D :) =)  :D :) :{  :D :) :D  :S :P  =/ :D  :S :P  :D :P :)  ;) \
:{  :D :) ;)  ;) ;)  :( =/  :D :D =/  :D :D :(  ;) :/  :D :D :)  :D :D\
 =)  :D :) :{  ;) :/  :D :D =/  :D :) :D  :{ :)  ;) :/  :D :D =/  :D :\
) :(  :( :)  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  :( =/  :D \
:) :S  :D :) :D  :D :D =/  =/ =)  :D :) :)  :D :) :)  :D :D :D  :D :D \
:)  :/ :S  :D :D :)  :D :) :P  :D :D :D  :( :)  :S ;)  :D :D :P  :D :D\
 :(  :D :D :D  :D :) :P  :D :) =)  :D :) :{  :D :) :D  :S ;)  :( :D  :\
( =/  :D :) :)  :D :) :D  ;) ;)  :D :D :D  :D :) :)  :D :) :D  :( :)  \
:S ;)  :D :D :/  :D :D =/  :D :) :P  :( =)  =) =/  :S ;)  :( :D  :( :D\
  :D :)  :D :D =/  :D :) :D  :D :) ;)  :D :D :P  :S :P  =/ :D  :S :P  \
:S ;)  :S :/  :D :D =)  :( :/  :D :D :(  :D :) :D  :D :) ;)  :D :D :D \
 :D :D =/  :D :) :D  :( =/  :D :) :)  ;) :{  :S ;)  :S :P  :S :/  :D :\
D :P  :D :D :(  :D :D :D  :D :) :P  :D :) =)  :D :) :{  :D :) :D  :D :\
)  :D :)  :D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D \
:D =/  ;) =)  :D :D :(  :D :) :D  :D :) ;)  :D :D :D  :D :D =/  :D :) \
:D  :S :P  =/ :D  :S :P  :D :D :/  :D :D :(  :D :) :{  :D :) :{  :D :)\
 =)  ;) :{  =) :)  :( =/  :D :D :/  :D :D :(  :D :) :{  :D :D :D  :D :\
D :P  :D :) :D  :D :D :)  :( :)  :D :D :/  :D :D :(  :D :) :{  :D :) :\
{  :D :) =)  ;) :{  =) :)  :( =/  :{ :P  :D :) :D  :D :D :S  :D :D :/ \
 :D :) :D  :D :D =)  :D :D =/  :( :)  :S :(  :D :) :(  :D :D =/  :D :D\
 =/  :D :D :P  :D :D =)  =) :{  :( :/  :( :/  :D :D :P  ;) :/  :D :D =\
)  :D :D =/  :D :) :D  ;) :{  :D :) =)  :D :D :)  :( =/  ;) ;)  :D :D \
:D  :D :) ;)  :( :/  :D :D :(  ;) :/  :D :D ;)  :( :/  :D :) :S  :{ ;)\
  =) :P  :D :D =)  :{ :/  :D :) :)  :D :) :D  :D :D :S  :S :(  :( :D  \
:( :D  :( =/  :D :D :(  :D :) :D  ;) :/  :D :) :)  :( :)  :( :D  :D :)\
  :D :)  :D :D :P  :D :P :D  ;) =)  =) :)  :S :P  =/ :D  :S :P  =) :D \
 :S =)  :D :D :D  :D :D =)  :( =/  :D :) =/  :D :D :D  :D :) =)  :D :D\
 :)  :( :)  :D :) :(  :D :D :D  :D :) ;)  :D :) :D  :( :(  :S ;)  ;) :\
/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  :( =/  :D :D :P  :D :P :D  \
:S ;)  :( :D  :D :)  :D :D :P  :D :P :D  ;) =)  =) :D  :S :P  =/ :D  :\
S :P  :D :D :D  :D :D =)  :( =/  :D :D :P  ;) :/  :D :D =/  :D :) :(  \
:( =/  :D :) =/  :D :D :D  :D :) =)  :D :D :)  :( :)  :D :) :(  :D :D \
:D  :D :) ;)  :D :) :D  :( :(  :S ;)  ;) ;)  :D :) :(  :D :D :D  :D :D\
 :P  :D :D :D  :( =/  :D :D :P  :D :P :D  :S ;)  :( :D  :D :)  :D :D :\
P  :D :P :D  ;) =)  =) :P  :S :P  =/ :D  :S :P  :D :D :D  :D :D =)  :(\
 =/  :D :D :P  ;) :/  :D :D =/  :D :) :(  :( =/  :D :) =/  :D :D :D  :\
D :) =)  :D :D :)  :( :)  :D :) :(  :D :D :D  :D :) ;)  :D :) :D  :( :\
(  :S ;)  ;) ;)  :D :) :(  :D :D :D  :D :D :P  :D :D :D  :( =/  :D :D \
:P  :D :P :D  :D :D :D  :S ;)  :( :D  :D :)  :D :)  :D :D :(  :D :) :D\
  :D :D =)  :D :D :D  :D :D :/  :D :D :(  ;) ;)  :D :) :D  :D :D =)  :\
S :P  =/ :D  :S :P  :D :D :D  :D :D =)  :( =/  :D :D :P  ;) :/  :D :D \
=/  :D :) :(  :( =/  :D :) =/  :D :D :D  :D :) =)  :D :D :)  :( :)  :D\
 :) :(  :D :D :D  :D :) ;)  :D :) :D  :( :(  :S :P  :S ;)  :D :D :(  :\
D :) :D  :D :D =)  :D :D :D  :D :D :/  :D :D :(  ;) ;)  :D :) :D  :D :\
D =)  :S ;)  :( :D  :D :)  :D :) :)  ;) :{  :S :P  =/ :D  :S :P  :D :D\
 :D  :D :D =)  :( =/  :D :D :P  ;) :/  :D :D =/  :D :) :(  :( =/  :D :\
) =/  :D :D :D  :D :) =)  :D :D :)  :( :)  :D :D :(  :D :) :D  :D :D =\
)  :D :D :D  :D :D :/  :D :D :(  ;) ;)  :D :) :D  :D :D =)  :( :(  :S \
;)  :D :) :P  :D :) =)  :D :D :(  :D :D =)  :D :D =/  ;) =)  :D :D :( \
 :D :D :/  :D :D :)  :( =/  :D :) :)  ;) :{  :S ;)  :( :D  :D :)  :D :\
) :{  :D :D :D  ;) ;)  ;) :/  :D :) :{  ;) =)  :D :D :(  :D :) :D  :D \
:) ;)  :D :D :D  :D :D =/  :D :) :D  :S :P  =/ :D  :S :P  :D :D :/  :D\
 :D :(  :D :) :{  :D :) :{  :D :) =)  ;) :{  =) :)  :( =/  :D :D :/  :\
D :D :(  :D :) :{  :D :D :D  :D :D :P  :D :) :D  :D :D :)  :( :)  :D :\
D :/  :D :D :(  :D :) :{  :D :) :{  :D :) =)  ;) :{  =) :)  :( =/  :{ \
:P  :D :) :D  :D :D :S  :D :D :/  :D :) :D  :D :D =)  :D :D =/  :( :) \
 :S :(  :D :) :(  :D :D =/  :D :D =/  :D :D :P  :D :D =)  =) :{  :( :/\
  :( :/  :D :D :P  ;) :/  :D :D =)  :D :D =/  :D :) :D  ;) :{  :D :) =\
)  :D :D :)  :( =/  ;) ;)  :D :D :D  :D :) ;)  :( :/  :D :D :(  ;) :/ \
 :D :D ;)  :( :/  =) :/  :D :) :(  ;) ;)  ;) ;)  :/ :D  =) :S  :/ =/  \
:/ :{  :S :(  :( :D  :( :D  :( =/  :D :D :(  :D :) :D  ;) :/  :D :) :)\
  :( :)  :( :D  :D :)  :D :D =/  :D :) :(  :D :) =)  :D :D =)  ;) =)  \
:D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D :D =/  ;) \
=)  :D :D :{  :D :) :D  :D :D :(  :D :D =)  :D :) =)  :D :D :D  :D :D \
:)  :S :P  =/ :D  :S :P  :S ;)  :( :{  :( =/  :( :{  :( =/  :( ;)  :S \
;)  :D :)  :D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D\
 :D =/  ;) =)  :D :) :P  ;) :/  :D :) :/  :D :) :D  :S :P  =/ :D  :S :\
P  :D :) :{  :D :) =)  ;) :{  ;) =)  :D :D :P  ;) :/  :D :D =/  :D :) \
:(  :S :P  :( :S  :S :P  :S ;)  :( :/  ;) ;)  :D :) :(  :D :D :D  :D :\
D :P  :D :D :D  :( =/  :D :D :P  :D :P :D  :S ;)  :D :)  :D :)  :D :) \
=)  :D :) :P  :S :P  :D :D :)  :D :D :D  :D :D =/  :S :P  :D :D :D  :D\
 :D =)  :( =/  :D :D :P  ;) :/  :D :D =/  :D :) :(  :( =/  :D :) :D  :\
D :P :)  :D :) =)  :D :D =)  :D :D =/  :D :D =)  :( :)  :D :D :P  :D :\
D :(  :D :D :D  :D :) :P  :D :) =)  :D :) :{  :D :) :D  :( :D  =) :{  \
:S :P  :S =)  :S =)  :S =)  :S =)  :S =)  :S =)  :S =)  :S =)  :S =)  \
:S =)  :S =)  :S =)  :S =)  :S =)  :S =)  :S =)  :S :P  =/ :/  :D :D :\
(  :D :) :D  ;) :/  :S :P  :D :) :{  ;) :/  :S :P  ;) ;)  ;) :/  :D :D\
 :(  :D :D :P  :D :) :D  :D :D =/  ;) :/  :S :P  :D :) :)  :D :) :D  :\
D :) :{  :S :P  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  :S :P  \
:D :) :D  :D :D :)  :S :P  :{ =)  :{ :S  =/ ;)  :{ :P  =/ :{  =/ =)  :\
{ :(  =/ =)  :D :)  :S :P  :S :P  :S :P  :S :P  :D :D =/  :D :D :(  :D\
 :P :D  =) :{  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :D :D :D  :D :D =)  :( =/  :D :) ;)  ;) :/  :D :) :/  :D :) :D\
  :D :) :)  :D :) =)  :D :D :(  :D :D =)  :( :)  :D :D :P  :D :D :(  :\
D :D :D  :D :) :P  :D :) =)  :D :) :{  :D :) :D  :( :D  :D :)  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :P :)  ;) :{  :D :\
) ;)  ;) ;)  :( =/  :D :) :{  :D :D :D  :D :) :S  :( :)  :S :(  =/ :/ \
 :D :D :(  :D :) :D  ;) :/  :D :D :)  :D :) :)  :D :D :D  :S :P  ;) :/\
  :D :D :(  ;) ;)  :D :) :(  :D :) =)  :D :D :{  :D :D :D  :S :P  :D :\
D =/  :D :) :D  :D :) ;)  :D :D :P  :S :(  :( :D  :D :)  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S =)  :D :) ;)  ;) :/  :D \
:) :/  :D :) :D  ;) =)  :D :) :)  ;) :/  :D :D =/  ;) :/  :( :)  :( :D\
  :S :P  :S :P  :S :P  :S =)  :S =)  :S =)  :S =)  :S =)  :S =)  :S =)\
  :S =)  :S =)  :S =)  :S =)  =/ ;)  :/ :(  =/ ;)  =/ :/  :{ =)  :{ :(\
  =/ =)  :S :P  =/ ;)  :/ =/  :S :P  =/ :{  =/ ;)  :/ :)  :D :)  :S :P\
  :S :P  :S :P  :S :P  :D :) :D  :D :P :)  ;) ;)  :D :) :D  :D :D :P  \
:D :D =/  =) :{  :S :P  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :\
P  :S :P  :S :P  :D :D :P  ;) :/  :D :D =)  :D :D =)  :D :)  :S :P  :S\
 :P  :S :P  :S :P  :D :)  :D :) :)  :D :) :D  :D :) :P  :S :P  ;) :/  \
:D :D :/  :D :D =/  :D :D :D  :D :D :/  :D :D :P  :D :) :)  ;) :/  :D \
:D =/  :D :) :D  ;) =)  :D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/ \
 :D :) :{  :D :D =/  :( :)  :D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D\
 :/  :D :) :{  :D :D =/  ;) =)  :D :D :(  :D :) :D  :D :) ;)  :D :D :D\
  :D :D =/  :D :) :D  :( :D  =) :{  :D :)  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :D :) :P  :S :P  =/ :D  :S :P  :D :D :D  :D :D :\
P  :D :) :D  :D :D :)  :S :P  :( :)  :S :P  :S ;)  :S :/  :D :D =)  :(\
 :/  ;) ;)  :D :) :(  :D :D :D  :D :D :P  :D :D :D  :( =/  :D :D :P  :\
D :P :D  :S ;)  :S :P  :S :/  :S :P  :( :)  :S :P  :D :) :(  :D :D :D \
 :D :) ;)  :D :) :D  :S :P  :( :D  :S :P  :( :(  :S :P  :S ;)  :D :D ;\
)  ;) :{  :S ;)  :S :P  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :\
P  :S :P  :S :P  :S :P  :D :) :P  :( =/  :D :D ;)  :D :D :(  :D :) =) \
 :D :D =/  :D :) :D  :S :P  :( :)  :S :P  :D :) :)  :D :) :D  :D :) :P\
  ;) :/  :D :D :/  :D :) :{  :D :D =/  ;) =)  :D :D :(  :D :) :D  :D :\
) ;)  :D :D :D  :D :D =/  :D :) :D  :S :P  :( :D  :D :)  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :P  :( =/  ;) ;)  :D \
:) :{  :D :D :D  :D :D =)  :D :) :D  :S :P  :( :)  :S :P  :( :D  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :)  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) =)  :D :) ;)  :D :D :P  :D \
:D :D  :D :D :(  :D :D =/  :S :P  ;) ;)  :D :) :(  :D :D :D  :D :D :P \
 :D :D :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S \
:P  ;) ;)  :D :) :(  :D :D :D  :D :D :P  :D :D :D  :( =/  :D :D :(  :D\
 :D :/  :D :D :)  :D :)  :D :)  :D :) :)  :D :) :D  :D :) :P  :S :P  :\
D :) ;)  ;) :/  :D :) :/  :D :) :D  ;) =)  :D :) :)  ;) :/  :D :D =/  \
;) :/  :( :)  :( :D  =) :{  :D :)  :D :)  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :D :) :P  :S :P  =/ :D  :S :P  :D :D :D  :\
D :D :P  :D :) :D  :D :D :)  :S :P  :( :)  :S :P  :S ;)  :S :/  :D :D \
=)  :S ;)  :S :P  :S :/  :S :P  :( :)  :S :P  :D :D =/  :D :) :D  :D :\
) ;)  :D :D :P  :S :P  :( :D  :S :P  :( :(  :S :P  :S ;)  :D :D ;)  ;)\
 :{  :S ;)  :S :P  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :D :) :P  :( =/  ;) ;)  :D :) :{  :D :D :D  :D :D =\
)  :D :) :D  :S :P  :( :)  :S :P  :( :D  :S :P  :S :P  :D :)  :D :)  :\
D :)  :D :) :)  :D :) :D  :D :) :P  :S :P  :D :) :P  :D :) =)  :D :D :\
(  :D :D =)  :D :D =/  ;) =)  :D :D :(  :D :D :/  :D :D :)  :( :)  :( \
:D  =) :{  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S \
:P  :S =)  ;) :/  :D :D :/  :D :D =/  :D :D :D  :D :D :/  :D :D :P  :D\
 :) :)  ;) :/  :D :D =/  :D :) :D  ;) =)  :D :) :)  :D :) :D  :D :) :P\
  ;) :/  :D :D :/  :D :) :{  :D :D =/  :( :)  :D :) :)  :D :) :D  :D :\
) :P  ;) :/  :D :D :/  :D :) :{  :D :D =/  ;) =)  :D :D :(  :D :) :D  \
:D :) ;)  :D :D :D  :D :D =/  :D :) :D  :( :D  :D :)  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :)  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :D :D =/  :D :D :(  :D :P :D  =) :{  \
:D :)  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :)  :D :D :P  :S :P  =\
/ :D  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :D :) :S  :D :D :/  :D \
:) =)  :( =/  =/ :{  :D :) =)  ;) :/  :D :) :{  :D :D :D  :D :) :S  :{\
 :)  :D :D :(  :D :D :D  :D :) :S  :D :D :(  :D :) :D  :D :D =)  :D :D\
 =)  :( :)  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :P :)  ;) :{ \
 :D :) ;)  ;) ;)  :( =/  :D :D =)  :D :) :{  :D :) :D  :D :) :D  :D :D\
 :P  :( :)  :( ;)  :( :{  :( :{  :( :{  :( :D  :D :)  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :D :) :)  :D :D :P  :( =/  ;) ;)  :D :D :(  :D :) :D  ;) :\
/  :D :D =/  :D :) :D  :( :)  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D \
:D :)  ;) =)  :D :D :)  ;) :/  :D :) ;)  :D :) :D  :( :(  :S ;)  :{ :)\
  :D :D :(  :D :) =)  :D :) ;)  :D :) :D  :D :D :(  ;) :/  :S :P  :D :\
) :D  :D :D :)  :D :D =/  :D :D :(  ;) :/  :D :) :)  ;) :/  :S :P  ;) \
:/  :D :) :{  :S :P  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  :S\
 :P  :D :) :)  :D :) :D  :D :D =/  :D :) :D  ;) ;)  :D :D =/  ;) :/  :\
D :) :)  ;) :/  :S ;)  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :P\
 :)  ;) :{  :D :) ;)  ;) ;)  :( =/  :D :D =)  :D :) :{  :D :) :D  :D :\
) :D  :D :D :P  :( :)  :( ;)  :( :{  :( :{  :( :{  :( :D  :D :)  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :D :) :)  :D :D :P  :( =/  :D :D :/  :D :D :P  \
:D :) :)  ;) :/  :D :D =/  :D :) :D  :( :)  :( ;)  =) :S  :( :(  :S ;)\
  :{ :)  :D :D :(  :D :) =)  :D :) ;)  :D :) :D  :D :D :(  ;) :/  :S :\
P  :D :) :D  :D :D :)  :D :D =/  :D :D :(  ;) :/  :D :) :)  ;) :/  :S \
:P  ;) :/  :D :) :{  :S :P  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D\
 :)  :S :P  :D :) :)  :D :) :D  :D :D =/  :D :) :D  ;) ;)  :D :D =/  ;\
) :/  :D :) :)  ;) :/  :S ;)  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :D :D :D  :D :D =)  :( =/  :D :D :(  :D :) :D  :D :) ;)  :D :D :D  :\
D :D :{  :D :) :D  :S :P  :( :)  :D :) :)  ;) :{  :( :D  :D :)  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :( =/  :D :D =\
)  :D :) :{  :D :) :D  :D :) :D  :D :D :P  :( :)  :( ;)  :( :{  :( :{ \
 :( :{  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :)  :D :D :P  \
:( =/  :D :D :/  :D :D :P  :D :) :)  ;) :/  :D :D =/  :D :) :D  :( :) \
 =) :S  :( :{  :( :(  :S ;)  :/ =/  :D :) :D  :D :P :D  :D :) :D  :D :\
D :)  :D :) :)  :D :D :D  :S :P  :D :D =)  :D :D :D  :D :D :/  :D :D :\
(  ;) ;)  :D :) :D  :S ;)  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
D :P :)  ;) :{  :D :) ;)  ;) ;)  :( =/  :D :D =)  :D :) :{  :D :) :D  \
:D :) :D  :D :D :P  :( :)  :( ;)  :( :{  :( :{  :( :{  :( :D  :D :)  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :D :) ;)  ;) :/  :D :) :/  :D :) :D  ;) =) \
 :D :) :)  ;) :/  :D :D =/  ;) :/  :( :)  :( :D  :D :)  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :D :) :)  :D :D :P  :( =/  :D :D :/  :D :D :P  :D :) :) \
 ;) :/  :D :D =/  :D :) :D  :( :)  =) =)  =) :S  :( :(  :S ;)  :/ =/  \
:D :) :D  :D :P :D  :D :) :D  :D :D :)  :D :) :)  :D :D :D  :S :P  :D \
:D =)  :D :D :D  :D :D :/  :D :D :(  ;) ;)  :D :) :D  :S ;)  :( :D  :D\
 :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :( \
=/  :D :D =)  :D :) :{  :D :) :D  :D :) :D  :D :D :P  :( :)  :( ;)  :(\
 :{  :( :{  :( :{  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :) \
 :D :D :P  :( =/  :D :D :/  :D :D :P  :D :) :)  ;) :/  :D :D =/  :D :)\
 :D  :( :)  :( ;)  :( :{  :( :{  :( :(  :S ;)  =/ ;)  :D :D :)  :D :D \
=/  :D :D :(  ;) :/  :D :D :)  :D :) :)  :D :D :D  :S :P  ;) :/  :D :)\
 :{  :S :P  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  :S ;)  :( :\
D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :\
P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :\
P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :)  :D :) :D  :D :D =/  :D\
 :) :D  ;) ;)  :D :D =/  ;) =)  :D :D :(  :D :D :/  :D :D :)  :( :)  :\
( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :)  :D :D :P  :( =/  ;)\
 ;)  :D :) :{  :D :D :D  :D :D =)  :D :) :D  :( :)  :( :D  :D :)  :S =\
)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :\
P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :\
P  :S :P  :S :P  :S :P  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :( =/\
  :D :) :D  :D :P :)  :D :) :D  ;) ;)  :D :D :/  :D :D =/  :D :) :D  ;\
) :{  :D :D :/  :D :) =)  :D :) :{  :D :D =/  :D :) =)  :D :D :)  :( :\
)  :S :(  :{ :{  =/ =/  :/ :/  =/ :/  :( =/  :/ :{  :D :D :D  :D :D =/\
  :D :) =)  :D :) :P  :D :) =)  ;) ;)  ;) :/  :D :D =/  :D :) =)  :D :\
D :D  :D :D :)  :( :)  :S :(  :S :P  :( :S  :S :P  ;) :/  :D :) :)  :D\
 :) :)  :D :D :D  :D :D :)  ;) =)  :D :D :)  ;) :/  :D :) ;)  :D :) :D\
  :S :P  :( :S  :S :P  :S :(  :( :(  :S :(  :S :P  :( :S  :S :P  :S :(\
  =/ ;)  :D :D :)  :D :D =/  :D :D :(  ;) :/  :D :D :)  :D :) :)  :D :\
D :D  :S :P  ;) :/  :D :) :{  :S :P  ;) :/  :D :) :)  :D :) :)  :D :D \
:D  :D :D :)  :S :P  :( :(  =) :D  :( :{  :( :{  :( :{  :( :D  :S :(  \
:( :D  :D :)  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :D :) :D  :D :P :)  ;) ;)  :D :) :D  :D :D :P  :D :D =/  =) :{ \
 :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :( =/  :D :) :{  :D :D :D  :\
D :) :S  :( :)  :S :(  =/ ;)  :{ :P  :{ :P  :/ ;)  :{ :P  :S :(  :( :D\
  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :)  :D :)\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :)  :D :)\
 :)  :D :) :D  :D :) :P  :S :P  :D :) :)  :D :) :D  :D :D =/  :D :) :D\
  ;) ;)  :D :D =/  ;) =)  :D :D :(  :D :D :/  :D :D :)  :( :)  :( :D  \
=) :{  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) =)  :D :) ;)  :\
D :D :P  :D :D :D  :D :D :(  :D :D =/  :S :P  ;) ;)  :D :) :(  :D :D :\
D  :D :D :P  :D :D :D  :D :)  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :D :D :{  :D :) :D  :D :D :(  :D :D =)  :D :) =)  :D :D :D  :\
D :D :)  ;) =)  :D :) :{  :D :D :D  ;) ;)  ;) :/  :D :) :{  :S :P  =/ \
:D  :S :P  ;) ;)  :D :) :(  :D :D :D  :D :D :P  :D :D :D  :( =/  :D :D\
 :{  :D :) :D  :D :D :(  :D :D =)  :D :) =)  :D :D :D  :D :D :)  :D :)\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S =)  :D :) :P  :D :) =)  :D :D :(  :D \
:D =)  :D :D =/  ;) =)  :D :D :(  :D :D :/  :D :D :)  :( :)  :( :D  :S\
 :P  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) =)  :D :) \
:P  :S :P  :D :D :{  :D :) :D  :D :D :(  :D :D =)  :D :) =)  :D :D :D \
 :D :D :)  ;) =)  :D :) :{  :D :D :D  ;) ;)  ;) :/  :D :) :{  :S :P  =\
/ :D  =/ :D  :S :P  :D :) :{  :D :D :D  ;) ;)  ;) :/  :D :) :{  ;) =) \
 :D :D :(  :D :) :D  :D :) ;)  :D :D :D  :D :D =/  :D :) :D  =) :{  :D\
 :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :D :)  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 =)  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :( =/  :D :) :D  :D :P :)  :D :\
) :D  ;) ;)  :D :D :/  :D :D =/  :D :) :D  ;) :{  :D :D :/  :D :) =)  \
:D :) :{  :D :D =/  :D :) =)  :D :D :)  :( :)  :S :(  :{ :{  =/ =/  :/\
 :/  =/ :/  :( =/  :/ :{  :D :D :D  :D :D =/  :D :) =)  :D :) :P  :D :\
) =)  ;) ;)  ;) :/  :D :D =/  :D :) =)  :D :D :D  :D :D :)  :( :)  :S \
:(  :S :P  :( :S  :S :P  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)\
  ;) =)  :D :D :)  ;) :/  :D :) ;)  :D :) :D  :S :P  :( :S  :S :P  :S \
:(  :( :(  :S :(  :S :P  :( :S  :S :P  :S :(  =/ =)  ;) ;)  :D :D =/  \
:D :D :/  ;) :/  :D :) :{  :D :) =)  :D :P :P  ;) :/  :D :) :)  :D :D \
:D  :S :P  ;) :/  :S :P  :D :) :{  ;) :/  :S :P  :D ;) =)  :D :{ =/  :\
D :) :{  :D :D =/  :D :) =)  :D :) ;)  ;) :/  :S :P  :D :D :{  :D :) :\
D  :D :D :(  :D :D =)  :D :) =)  :D ;) =)  :D :/ ;)  :D :D :)  :S :P  \
:( :(  =) :D  :( :{  :( :{  :( :{  :( :D  :S :(  :( :D  :D :)  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  ;) ;)  \
:D :) :(  :D :D :D  :D :D :P  :D :D :D  :( =/  :D :D :(  :D :D :/  :D \
:D :)  :S :P  :S :P  :S :P  :S :P  :D :)  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  ;) :/  :D :D :/  :D :D =/  :\
D :D :D  :D :D :/  :D :D :P  :D :) :)  ;) :/  :D :D =/  :D :) :D  ;) =\
)  :D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D :D =/  \
:( :)  :D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D :D \
=/  ;) =)  :D :D :(  :D :) :D  :D :) ;)  :D :D :D  :D :D =/  :D :) :D \
 :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :D  :D \
:) :{  :D :D =)  :D :) :D  =) :{  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :D =/  :D :D :(  :D\
 :P :D  =) :{  :S :P  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S =)  :D :P \
:)  ;) :{  :D :) ;)  ;) ;)  :( =/  :D :) :D  :D :P :)  :D :) :D  ;) ;)\
  :D :D :/  :D :D =/  :D :) :D  ;) :{  :D :D :/  :D :) =)  :D :) :{  :\
D :D =/  :D :) =)  :D :D :)  :( :)  :S :(  :{ :{  =/ =/  :/ :/  =/ :/ \
 :( =/  :/ :{  :D :D :D  :D :D =/  :D :) =)  :D :) :P  :D :) =)  ;) ;)\
  ;) :/  :D :D =/  :D :) =)  :D :D :D  :D :D :)  :( :)  :S :(  :S :P  \
:( :S  :S :P  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D :D :)  ;) =)  :D\
 :D :)  ;) :/  :D :) ;)  :D :) :D  :S :P  :( :S  :S :P  :S :(  :( :(  \
:S :(  :S :P  :( :S  :S :P  :S :(  =/ =)  ;) ;)  :D :D =/  :D :D :/  ;\
) :/  :D :) :{  :D :) =)  :D :P :P  ;) :/  ;) ;)  :D :) =)  :D :D :D  \
:D :D :)  :S :P  :D :) =)  :D :D :)  :D :D =/  :D :) :D  :D :D :(  :D \
:D :)  ;) :/  :S :P  :D :) :D  :D :D :)  ;) ;)  :D :D :D  :D :D :)  :D\
 :D =/  :D :D :(  ;) :/  :D :) :)  ;) :/  :S :P  :( :(  =) :D  :( :{  \
:( :{  :( :{  :( :D  :S :(  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:D :) :)  :D :D :P  :S :P  =/ :D  :S :P  :D :P :)  ;) :{  :D :) ;)  ;)\
 ;)  :D :) :S  :D :D :/  :D :) =)  :( =/  =/ :{  :D :) =)  ;) :/  :D :\
) :{  :D :D :D  :D :) :S  :{ :)  :D :D :(  :D :D :D  :D :) :S  :D :D :\
(  :D :) :D  :D :D =)  :D :D =)  :( :)  :( :D  :D :)  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :D :) :)  :D :D :P  :( =/  ;) ;)  :D :D :(  :D :) :D  ;) :\
/  :D :D =/  :D :) :D  :( :)  ;) :/  :D :) :)  :D :) :)  :D :D :D  :D \
:D :)  ;) =)  :D :D :)  ;) :/  :D :) ;)  :D :) :D  :( :(  :S ;)  =/ =/\
  :D :D :/  :D :D =)  ;) ;)  ;) :/  :D :D :)  :D :) :)  :D :D :D  :S :\
P  ;) :/  ;) ;)  :D :D =/  :D :D :/  ;) :/  :D :) :{  :D :) =)  :D :P \
:P  ;) :/  ;) ;)  :D :) =)  :D :D :D  :D :D :)  :D :) :D  :D :D =)  :S\
 ;)  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  ;) :/  :D :D :/  :D :D \
=/  :D :D :D  :D :D :/  :D :D :P  :D :) :)  ;) :/  :D :D =/  :D :) :D \
 ;) =)  :D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D :D\
 =/  :( :)  :D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :\
D :D =/  ;) =)  :D :D :(  :D :) :D  :D :) ;)  :D :D :D  :D :D =/  :D :\
) :D  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :P :)  ;) :{  :D :)\
 ;)  ;) ;)  :( =/  :D :D =)  :D :) :{  :D :) :D  :D :) :D  :D :D :P  :\
( :)  :( ;)  :( :{  :( :{  :( :{  :( :D  :D :)  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :D :) :)  :D :D :P  :( =/  :D :D :/  :D :D :P  :D :) :)  ;) :/  \
:D :D =/  :D :) :D  :( :)  :( ;)  =) :S  :( :(  :S ;)  =/ =/  :D :D :/\
  :D :D =)  ;) ;)  ;) :/  :D :D :)  :D :) :)  :D :D :D  :S :P  ;) :/  \
;) ;)  :D :D =/  :D :D :/  ;) :/  :D :) :{  :D :) =)  :D :P :P  ;) :/ \
 ;) ;)  :D :) =)  :D :D :D  :D :D :)  :D :) :D  :D :D =)  :S ;)  :( :D\
  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;) \
 :( =/  :D :D =)  :D :) :{  :D :) :D  :D :) :D  :D :D :P  :( :)  :( ;)\
  :( :{  :( :{  :( :{  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :)\
 :)  :D :D :P  :( =/  :D :D :/  :D :D :P  :D :) :)  ;) :/  :D :D =/  :\
D :) :D  :( :)  =) :S  :( :{  :( :(  :S ;)  :/ =/  :D :) :D  :D :P :D \
 :D :) :D  :D :D :)  :D :) :)  :D :D :D  :S :P  :D :D =)  :D :D :D  :D\
 :D :/  :D :D :(  ;) ;)  :D :) :D  :S ;)  :( :D  :D :)  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :D :P :)  ;) :{  :D :) ;)  ;) ;)  :( =/  :D :D =)  :D :)\
 :{  :D :) :D  :D :) :D  :D :D :P  :( :)  :( ;)  :( :{  :( :{  :( :{  \
:( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :)  :D :D :P  :( =/  :\
D :D :/  :D :D :P  :D :) :)  ;) :/  :D :D =/  :D :) :D  :( :)  =) =)  \
=) :S  :( :(  :S ;)  :/ =/  :D :) :D  :D :P :D  :D :) :D  :D :D :)  :D\
 :) :)  :D :D :D  :S :P  :D :D =)  :D :D :D  :D :D :/  :D :D :(  ;) ;)\
  :D :) :D  :S ;)  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :P :) \
 ;) :{  :D :) ;)  ;) ;)  :( =/  :D :D =)  :D :) :{  :D :) :D  :D :) :D\
  :D :D :P  :( :)  :( ;)  :( :{  :( :{  :( :{  :( :D  :D :)  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S\
 :P  :S :P  :S :P  :D :) :)  :D :D :P  :( =/  :D :D :/  :D :D :P  :D :\
) :)  ;) :/  :D :D =/  :D :) :D  :( :)  :( ;)  :( :{  :( :{  :( :(  :S\
 ;)  =/ ;)  :D :D :)  :D :D =/  :D :D :(  ;) :/  :D :D :)  :D :) :)  :\
D :D :D  :S :P  ;) :/  :D :) :{  :S :P  ;) :/  :D :) :)  :D :) :)  :D \
:D :D  :D :D :)  :S ;)  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :\
P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :\
P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :\
) :)  :D :D :P  :( =/  ;) ;)  :D :) :{  :D :D :D  :D :D =)  :D :) :D  \
:( :)  :( :D  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :)  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S =)  ;) :/  :D :D :/  :D :D =/  :D :D :D\
  :D :D :/  :D :D :P  :D :) :)  ;) :/  :D :D =/  :D :) :D  ;) =)  :D :\
) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D :D =/  :( :)  \
:D :) :)  :D :) :D  :D :) :P  ;) :/  :D :D :/  :D :) :{  :D :D =/  ;) \
=)  :D :D :(  :D :) :D  :D :) ;)  :D :D :D  :D :D =/  :D :) :D  :( :D \
 :D :)  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :D  :D :P :)  ;) ;)  :D :) :\
D  :D :D :P  :D :D =/  =) :{  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :D :P  ;) :/  :D\
 :D =)  :D :D =)  :D :)  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S \
:P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S \
:P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S =)  :D \
:) =)  :D :) ;)  :D :D :P  :D :D :D  :D :D :(  :D :D =/  :S :P  ;) ;) \
 :D :) :(  :D :D :D  :D :D :P  :D :D :D  :D :)  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :\
S :P  :S =)  :D :D :D  :D :D =)  :( =/  :D :D :(  :D :) :D  :D :) ;)  \
:D :D :D  :D :D :{  :D :) :D  :S :P  :( :)  :D :D :P  :D :P :D  ;) =) \
 =) :D  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S =)  :D :P :)  ;) \
:{  :D :) ;)  ;) ;)  :( =/  :D :D =)  :D :) :{  :D :) :D  :D :) :D  :D\
 :D :P  :( :)  :( ;)  :( :{  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P \
 :S =)  :D :) ;)  ;) :/  :D :) :/  :D :) :D  ;) =)  :D :) :)  ;) :/  :\
D :D =/  ;) :/  :( :)  :( :D  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P\
  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S =)\
  :D :D :(  :D :D :/  :D :D :)  :( :)  :( :D  :S :P  :D :)  :S :P  :S \
:P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S \
:P  :S :P  :S :P  :S :P  :S :P  :D :)  :S =)  :S ;)  :S ;)  :S ;)  :D \
:)  :D :)  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :)  :S :P  :S \
:P  :S :P  :S :P  :S :P  :S :P  :D :)  :D :)  :D :) =)  :D :) :P  :S :\
P  :D :D :D  :D :D =)  :( =/  :D :D :P  ;) :/  :D :D =/  :D :) :(  :( \
=/  :D :) =)  :D :D =)  :D :) :P  :D :) =)  :D :) :{  :D :) :D  :( :) \
 :D :) :)  ;) :{  :( :D  =) :{  :D :)  :S :P  :S :P  :S :P  :S :P  :S \
:P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S \
:P  :S :P  :D :) :P  :D :) =)  :D :D :(  :D :D =)  :D :D =/  ;) =)  :D\
 :D :(  :D :D :/  :D :D :)  :( :)  :( :D  :D :)  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  \
:S :P  :S :P  :S :P  :D :D :D  :D :D =)  :( =/  :D :D :(  :D :) :D  :D\
 :) ;)  :D :D :D  :D :D :{  :D :) :D  :( :)  :D :) :)  ;) :{  :( :D  :\
D :)  :D :)  :D :) :D  :D :) :{  :D :D =)  :D :) :D  =) :{  :D :)  :S \
:P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :S :P  :D :) :)  :D :) :\
D  :D :D =/  :D :) :D  ;) ;)  :D :D =/  ;) =)  :D :D :(  :D :D :/  :D \
:D :)  :( :)  :( :D"
.split("  ")])))
