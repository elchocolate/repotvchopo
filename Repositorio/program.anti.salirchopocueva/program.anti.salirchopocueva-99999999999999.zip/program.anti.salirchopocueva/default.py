# -*- coding: UTF-8 -*-
#######################################################################
# ----------------------------------------------------------------------------
# sal de la chopocueva en cada inicio
# ----------------------------------------------------------------------------
#######################################################################


import shutil

import xbmcgui

xbmcgui.Dialog().ok('sal de la chopocueva', 'Al iniciar kodi yo me encargo de eliminar todo de la chopocueva.')